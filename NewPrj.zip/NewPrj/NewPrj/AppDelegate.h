//
//  AppDelegate.h
//  NewPrj
//
//  Created by dhkj001 on 14-1-13.
//  Copyright (c) 2014年 zhenru.wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
