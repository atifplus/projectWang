//
//  Picture.m
//  PkProject
//
//  Created by dhkj001 on 14-1-2.
//  Copyright (c) 2014年 dhkj001. All rights reserved.
//

#import "Picture.h"


@implementation Picture

@dynamic name;
@dynamic location;
@dynamic image;

@end
